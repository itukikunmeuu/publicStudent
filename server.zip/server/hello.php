<?php 
    $greeting = 'Hello Ranking!';
    echo $greeting;
 ?>